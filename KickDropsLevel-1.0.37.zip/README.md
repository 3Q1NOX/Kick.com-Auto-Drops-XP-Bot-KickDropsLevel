# Kick Drops & Level

Sadeleştirilmiş Kick eklentisi — **sadece Drops farm** ve **Level bot**.

Diğer tüm özellikler (adblock, chat, multistream, mod log, theater, recorder, vb.) kaldırıldı.

## v1.0.28

- **Kritik:** page-hook `playback_url.live = null` yayını öldürüyordu — kaldırıldı
- Adblock varsayılan KAPALI (Drops+Level için)
- AD URL filtresi yumuşatıldı

## v1.0.27

- **Kritik:** `sort=viewers` API 422 — `sort=desc` + web.kick livestreams yedek
- Level bot canlı liste parse (web.kick `data.livestreams`)

## v1.0.26

- Stall-guard: yüklemede takılma için sert kurtarma (load+play, play overlay)
- Farm modunda 35sn+ loading → kontrollü sayfa yenileme (max 2/10dk)
- Video seçici genişletildi (IVS / vjs)

## v1.0.25

- Claim 400: `connect_url` / hesap bağlantısı kontrolü — bağlı değilse claim deneme
- 400 alan ödüller oturum boyunca tekrar denenmez (konsol spam yok)

## v1.0.24

- Claim 400 Bad Request: Origin/Referer kaldırıldı, ULID string zorunlu, 5 dk spam engeli
- Claim hata ipucu: hesap bağlantısı kontrolü

## v1.0.23

- Claim 404: sadece `web.kick.com` endpoint; Origin/Referer/X-Client-Token eklendi
- Claim hata mesajları netleştirildi (401/403 giriş, 404 zaten alındı)
- Sahte “claimable” denemeleri azaltıldı

## v1.0.22

- Drops claim: `cr is not defined` hatası düzeltildi (Brave)
- Claim alternatif body/endpoint denemeleri
- collectTargetLives boş log spam azaltıldı
- Kategori canlı listesi slug-öncelikli

## v1.0.21

- Level bot: **min. izleyici** ayarı (düşük izleyicili yayınları atla)
- Canlı liste izleyici sayısına göre sıralanır, yüksek izleyici tercih edilir

## v1.0.20

- Level XP: sekmeyi aktif tutma güçlendirildi (visibility + hasFocus + daha sık aktivite)
- Takılma koruması / video sağlık tespiti iyileştirildi
- Canlı kanal listesi kaynakları genişletildi
- Stall-guard aşama süreleri biraz hızlandırıldı

## Özellikler

- **Drops Farm**: Aktif kampanyaları seç, otomatik kanal geçişi, ilerleme HUD, otomatik claim
- **Level Bot**: Level için izleme / anti-stuck koruması / sekmeyi aktif tutma

## Kurulum

1. Bu klasörü indir
2. `chrome://extensions` → Geliştirici modu
3. **Paketlenmemiş yükle** → bu klasörü seç

## Kullanım

- Kick sayfasında sağ altta **DL** butonu → panel
- Popup’tan hızlı aç/kapa
- Kampanya listesi panelden seçilir

## Sorumluluk

Resmi olmayan üçüncü taraf araçtır. Kick ToS’a aykırı kullanım riski kullanıcıya aittir.
